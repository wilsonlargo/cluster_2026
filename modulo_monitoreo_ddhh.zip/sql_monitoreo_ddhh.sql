-- Módulo Monitoreo DDHH - estructura inicial Supabase
-- Ejecutar en Supabase SQL Editor.

create extension if not exists pgcrypto with schema extensions;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists public.monitoreo_fuentes (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  url text not null unique,
  tipo text not null default 'rss' check (tipo in ('rss', 'web', 'institucional', 'organizacion', 'medio')),
  categoria text,
  activa boolean not null default true,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.monitoreo_reglas (
  id uuid primary key default gen_random_uuid(),
  nombre text not null unique,
  palabras_incluir text[] not null default '{}',
  palabras_excluir text[] not null default '{}',
  prioridad text not null default 'media' check (prioridad in ('alta', 'media', 'baja')),
  activa boolean not null default true,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.monitoreo_items (
  id uuid primary key default gen_random_uuid(),
  fuente_id uuid references public.monitoreo_fuentes(id) on delete set null,
  titulo text not null,
  url text not null unique,
  resumen text,
  fecha_publicacion timestamptz,
  fecha_detectado timestamptz not null default now(),
  puntaje_relevancia integer not null default 0,
  prioridad text not null default 'media' check (prioridad in ('alta', 'media', 'baja')),
  estado_revision text not null default 'pendiente' check (estado_revision in ('pendiente', 'relevante', 'descartado', 'duplicado', 'registrado_como_caso')),
  departamento_detectado text,
  municipio_detectado text,
  pueblo_detectado text,
  palabras_clave text[] not null default '{}',
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists monitoreo_fuentes_activa_idx on public.monitoreo_fuentes(activa);
create index if not exists monitoreo_items_estado_idx on public.monitoreo_items(estado_revision);
create index if not exists monitoreo_items_prioridad_idx on public.monitoreo_items(prioridad);
create index if not exists monitoreo_items_fecha_detectado_idx on public.monitoreo_items(fecha_detectado desc);
create index if not exists monitoreo_items_fuente_idx on public.monitoreo_items(fuente_id);

-- Triggers updated_at
drop trigger if exists set_updated_at_monitoreo_fuentes on public.monitoreo_fuentes;
create trigger set_updated_at_monitoreo_fuentes
before update on public.monitoreo_fuentes
for each row execute function public.set_updated_at();

drop trigger if exists set_updated_at_monitoreo_reglas on public.monitoreo_reglas;
create trigger set_updated_at_monitoreo_reglas
before update on public.monitoreo_reglas
for each row execute function public.set_updated_at();

drop trigger if exists set_updated_at_monitoreo_items on public.monitoreo_items;
create trigger set_updated_at_monitoreo_items
before update on public.monitoreo_items
for each row execute function public.set_updated_at();

-- Seguridad: solo usuarios autenticados pueden usar el módulo.
alter table public.monitoreo_fuentes enable row level security;
alter table public.monitoreo_reglas enable row level security;
alter table public.monitoreo_items enable row level security;

drop policy if exists "monitoreo_fuentes_select_auth" on public.monitoreo_fuentes;
create policy "monitoreo_fuentes_select_auth"
on public.monitoreo_fuentes for select
to authenticated
using (true);

drop policy if exists "monitoreo_fuentes_insert_auth" on public.monitoreo_fuentes;
create policy "monitoreo_fuentes_insert_auth"
on public.monitoreo_fuentes for insert
to authenticated
with check (true);

drop policy if exists "monitoreo_fuentes_update_auth" on public.monitoreo_fuentes;
create policy "monitoreo_fuentes_update_auth"
on public.monitoreo_fuentes for update
to authenticated
using (true)
with check (true);

drop policy if exists "monitoreo_reglas_select_auth" on public.monitoreo_reglas;
create policy "monitoreo_reglas_select_auth"
on public.monitoreo_reglas for select
to authenticated
using (true);

drop policy if exists "monitoreo_reglas_insert_auth" on public.monitoreo_reglas;
create policy "monitoreo_reglas_insert_auth"
on public.monitoreo_reglas for insert
to authenticated
with check (true);

drop policy if exists "monitoreo_reglas_update_auth" on public.monitoreo_reglas;
create policy "monitoreo_reglas_update_auth"
on public.monitoreo_reglas for update
to authenticated
using (true)
with check (true);

drop policy if exists "monitoreo_items_select_auth" on public.monitoreo_items;
create policy "monitoreo_items_select_auth"
on public.monitoreo_items for select
to authenticated
using (true);

drop policy if exists "monitoreo_items_insert_auth" on public.monitoreo_items;
create policy "monitoreo_items_insert_auth"
on public.monitoreo_items for insert
to authenticated
with check (true);

drop policy if exists "monitoreo_items_update_auth" on public.monitoreo_items;
create policy "monitoreo_items_update_auth"
on public.monitoreo_items for update
to authenticated
using (true)
with check (true);

-- Reglas iniciales de depuración.
insert into public.monitoreo_reglas (nombre, palabras_incluir, palabras_excluir, prioridad)
values
  ('Amenazas a pueblos indígenas', array['amenaza','amenazas','líder indígena','autoridad indígena','guardia indígena','pueblo indígena','comunidad indígena'], array['turismo','festival','gastronomía','artesanías','moda','emprendimiento'], 'alta'),
  ('Desplazamiento y confinamiento', array['desplazamiento','confinamiento','comunidades indígenas','resguardo','violencia armada'], array['turismo','festival','feria'], 'alta'),
  ('Reclutamiento NNA indígenas', array['reclutamiento','NNA','niños indígenas','niñas indígenas','adolescentes indígenas'], array['festival','cultura','emprendimiento'], 'alta'),
  ('Informes institucionales', array['informe','alerta temprana','derechos humanos','pueblos indígenas'], array['turismo','gastronomía'], 'media')
on conflict (nombre) do nothing;
