Monitor fix territorio departamento v2

Correcciones:
- Al agregar municipio, toma el departamento seleccionado como respaldo directo.
- Guarda departamento y macroregion en casos_2026 al agregar el municipio.
- Al refrescar la territorialización, usa el departamento/macroregion ya guardados en el caso si el municipio no se resuelve por nombre.
- Índice municipal reforzado por departamento + municipio para evitar problemas con municipios repetidos.
- Coordenadas con coma decimal se normalizan para lat/lng.

Reemplazar:
- monitor.html
- js/main.js

Recargar con Ctrl + Shift + R.
