Modulo_Publico_Observatorio_v4_microinforme

Ajuste de textos visibles para que la página se presente como microinforme público.
Se mantuvo la funcionalidad de indicadores, rankings, tabla, mapas y botón de regreso.
