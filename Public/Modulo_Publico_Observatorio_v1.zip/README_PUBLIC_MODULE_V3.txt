Modulo Publico Observatorio v3

Cambios:
- Se agregó botón "Volver al inicio" en la barra superior.
- El botón apunta a ../index.html porque index.html está al lado de la carpeta Public.
- Se agregó una introducción institucional/académica sobre el proyecto de investigación.
- Se agregó correo de contacto: wilson.largo.s@gmail.com.
- No se modificó la lógica de datos ni de mapas en public.js.
