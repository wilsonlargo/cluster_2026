Modulo_Publico_Observatorio_v5_fuentes

Cambios incluidos:
- Se actualiza la introducción para presentar el microinforme como proyecto voluntario de investigación.
- Se explican dos momentos documentales: 2016–2024 y 2025–actualidad.
- Se agrega sección final de referencias documentales con formato bibliográfico.
- Se mantienen mapas, indicadores, rankings, tabla territorial y botón Volver al inicio.
- Se ajustan mensajes visibles para evitar menciones técnicas o de plataformas.

Instalación:
Reemplazar la carpeta Public con estos dos archivos:
- public.html
- public.js

Después recargar el navegador con Ctrl + Shift + R.
