SIG · Rutas desplazamientos v2

Esta versión usa el archivo “Rutas unificadas II.json” como fuente principal y agrega un archivo configurado:

- Rutas_unificadas_II_configurado.json

Funcionamiento:
1. Abrir SIG/sigindex.html.
2. Ir a Funcionalidades > Rutas desplazamientos.
3. Usar “Cargar rutas unificadas”.
4. El sistema lista 29 desplazamientos y dibuja origen, destino y líneas con Leaflet.
5. Al hacer clic sobre una línea o punto aparece el popup con año, pueblo, actor, tipo, personas, origen y destino.
6. También se puede cargar manualmente el archivo original “Rutas unificadas II.json”; el lector v2 reconoce ese formato.

No escribe datos en Supabase. Todo se carga y dibuja en navegador.
