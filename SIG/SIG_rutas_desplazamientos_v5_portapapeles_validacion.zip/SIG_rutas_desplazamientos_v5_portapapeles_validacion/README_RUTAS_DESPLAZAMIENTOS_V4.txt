SIG rutas desplazamientos v4

Cambios principales:
- Corrige el problema de puntos en 0,0: esa coordenada se trata como vacía.
- Los puntos de origen y destino ahora son arrastrables en el mapa.
- Al arrastrar un punto, se actualizan las coordenadas de la ruta seleccionada.
- El formulario permite escribir latitud/longitud manualmente para origen y destino.
- Agrega botones Buscar origen y Buscar destino usando el texto de lugar + departamento.
- La búsqueda aplica la coordenada encontrada, pero se recomienda revisar y mover el punto si requiere precisión territorial.
- Exportar JSON conserva rutas nuevas, rutas eliminadas, puntos movidos y coordenadas editadas.

Instalación:
Reemplazar en la carpeta SIG: sigindex.html y desplazamientosig.js.
Conservar configlayers.js, datasig.js, consolasig.js y los archivos JSON de rutas.
Recargar con Ctrl + Shift + R.
