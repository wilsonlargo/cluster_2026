SIG · Rutas desplazamientos v5

Cambios principales:
- Agrega botón "Pegar JSON" en Funcionalidades > Rutas desplazamientos.
- Permite leer el portapapeles o pegar manualmente un JSON.
- Valida la estructura antes de cargarla.
- Acepta:
  1. JSON original tipo "Rutas unificadas II".
  2. JSON exportado por el módulo con arreglo "desplazamientos".
  3. Una ruta individual con estructura layer/line.
  4. Arreglos planos de rutas.
- Muestra conteo de rutas reconocidas, rutas trazadas, parciales y sin coordenadas.
- Advierte si faltan origen/destino o coordenadas.
- Permite agregar el JSON pegado al listado actual.
- Permite reemplazar el listado actual por el JSON pegado.
- Conserva edición, eliminación, búsqueda de coordenadas, arrastre de puntos y exportación JSON.

Archivos a reemplazar en la carpeta SIG:
- sigindex.html
- desplazamientosig.js

Conservar:
- configlayers.js
- datasig.js
- consolasig.js
- Rutas_unificadas_II_configurado.json
- Rutas unificadas II.json

Uso sugerido:
1. Abrir Funcionalidades > Rutas desplazamientos.
2. Presionar Pegar JSON.
3. Leer portapapeles o pegar manualmente.
4. Validar.
5. Agregar al listado o reemplazar listado.
6. Ajustar coordenadas con búsqueda, clic en mapa o arrastre.
7. Exportar JSON para guardar cambios.
