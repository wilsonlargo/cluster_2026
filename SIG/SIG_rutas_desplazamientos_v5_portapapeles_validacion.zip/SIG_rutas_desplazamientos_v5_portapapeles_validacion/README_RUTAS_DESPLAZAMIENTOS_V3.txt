SIG · Rutas desplazamientos v3

Cambios frente a v2:
- Se mantiene el menú Funcionalidades > Rutas desplazamientos.
- Se mantiene carga automática de Rutas_unificadas_II_configurado.json.
- Se puede cargar archivo JSON o CSV externo.
- Se puede crear una ruta nueva desde el panel lateral.
- Se puede editar la ficha básica de una ruta seleccionada: año, pueblo, actor, tipo, personas, origen, destino, color, grosor, trazo y detalle.
- Se puede marcar origen y destino haciendo clic sobre el mapa.
- Se puede eliminar la ruta seleccionada.
- Al exportar JSON, el archivo descargado conserva las rutas actuales, incluyendo rutas nuevas, rutas eliminadas y coordenadas modificadas.

Uso recomendado:
1. Abrir SIG/sigindex.html.
2. Entrar en Funcionalidades > Rutas desplazamientos.
3. Cargar rutas unificadas o cargar otro archivo.
4. Crear, editar o eliminar rutas según se requiera.
5. Marcar origen/destino cuando sea necesario.
6. Exportar JSON para guardar una nueva versión del archivo.

Nota:
Esta versión no escribe cambios en Supabase ni reemplaza automáticamente el archivo original en disco. Los cambios se conservan al descargar el JSON exportado.
