SIG console terminal v5 popup fix

Cambios:
- Recupera popups exactos de municipios: MPIO_CNMBR y DEPTO.
- Recupera popups de resguardos con Pueblo, Departamento, Municipio y Nombre.
- Los puntos normales del SIG se enriquecen cruzando sig_casos_public_2026 con casos_2026.
- Los puntos de consola abren popup manual y bindPopup, con detalle, detalle_lugar, fuente, fecha fuente, enlace y contexto.
- Se mantiene consola terminal, marcadores acumulables, copiar tabla y guardar/cargar comandos.

Instalación:
Reemplazar sigindex.html, configlayers.js, datasig.js y consolasig.js. Luego Ctrl+Shift+R.
