-- 10_sig_tablas_ligeras_sin_timeout.sql
-- Reconstrucción del SIG para evitar timeouts: tablas físicas ligeras, opciones preconstruidas
-- y puntos separados. No usa RPC para filtros, mapa ni consola.

begin;

create extension if not exists pg_trgm;

-- ================================================================
-- 0. Limpiar objetos de esta versión
-- ================================================================

drop table if exists public.sig_filtros_opciones_2026 cascade;
drop table if exists public.sig_casos_detalle_2026 cascade;
drop table if exists public.sig_puntos_lite_2026 cascade;
drop table if exists public.sig_casos_lite_2026 cascade;
drop function if exists public.refresh_sig_lite_2026();
drop function if exists public._sig_jsonb_text_list(jsonb);

-- ================================================================
-- 1. Función auxiliar: convierte jsonb de arreglos/objetos en texto plano
-- ================================================================

create or replace function public._sig_jsonb_text_list(j jsonb)
returns text
language sql
immutable
as $$
  select coalesce(
    string_agg(distinct nullif(btrim(valor), ''), ' | ' order by nullif(btrim(valor), '')),
    ''
  )
  from (
    select
      case
        when elem is null then null
        when jsonb_typeof(elem) = 'string' then elem #>> '{}'
        when jsonb_typeof(elem) = 'object' then coalesce(
          elem ->> 'nombre',
          elem ->> 'pueblo',
          elem ->> 'label',
          elem ->> 'name',
          elem ->> 'valor',
          elem ->> 'value',
          elem::text
        )
        else elem::text
      end as valor
    from jsonb_array_elements(
      case
        when j is null then '[]'::jsonb
        when jsonb_typeof(j) = 'array' then j
        else jsonb_build_array(j)
      end
    ) as e(elem)
  ) s;
$$;

-- ================================================================
-- 2. Tabla pública ligera: un registro por caso, sin JSON pesado
-- ================================================================

create table public.sig_casos_lite_2026 (
  caso_id uuid primary key,
  fecha_evento date,
  anio int,
  macrotipo text,
  subtipos_texto text,
  departamento text,
  macroregion text,
  pueblo_texto text,
  npersonas bigint default 0,
  nmujeres bigint default 0,
  nhombres bigint default 0,
  nmenores bigint default 0,
  macroactor text,
  microactores_texto text
);

insert into public.sig_casos_lite_2026 (
  caso_id, fecha_evento, anio, macrotipo, subtipos_texto, departamento, macroregion,
  pueblo_texto, npersonas, nmujeres, nhombres, nmenores, macroactor, microactores_texto
)
select
  c.id,
  c.fecha_evento,
  extract(year from c.fecha_evento)::int,
  nullif(btrim(c.macrotipo), ''),
  public._sig_jsonb_text_list(c.subtipos),
  nullif(btrim(c.departamento), ''),
  nullif(btrim(c.macroregion), ''),
  public._sig_jsonb_text_list(c.pueblo),
  coalesce(c.npersonas, 0)::bigint,
  coalesce(c.nmujeres, 0)::bigint,
  coalesce(c.nhombres, 0)::bigint,
  coalesce(c.nmenores, 0)::bigint,
  nullif(btrim(c.macroactor), ''),
  public._sig_jsonb_text_list(c.microactores)
from public.casos_2026 c;

-- ================================================================
-- 3. Tabla de puntos: un registro por caso-municipio
-- ================================================================

create table public.sig_puntos_lite_2026 (
  id bigserial primary key,
  caso_id uuid not null,
  municipio text,
  departamento text,
  macroregion text,
  lat double precision,
  lng double precision
);

insert into public.sig_puntos_lite_2026 (caso_id, municipio, departamento, macroregion, lat, lng)
select
  c.id,
  nullif(btrim(cm.municipio), ''),
  nullif(btrim(c.departamento), ''),
  nullif(btrim(c.macroregion), ''),
  cm.lat,
  cm.lng
from public.casos_2026 c
join public.caso_municipio_2026 cm on cm.caso_id = c.id
where cm.lat is not null
  and cm.lng is not null;

-- ================================================================
-- 4. Tabla avanzada autenticada: incluye detalle y texto de búsqueda
-- ================================================================

create table public.sig_casos_detalle_2026 (
  caso_id uuid primary key,
  fecha_evento date,
  anio int,
  macrotipo text,
  subtipos_texto text,
  departamento text,
  macroregion text,
  pueblo_texto text,
  npersonas bigint default 0,
  nmujeres bigint default 0,
  nhombres bigint default 0,
  nmenores bigint default 0,
  macroactor text,
  microactores_texto text,
  detalle text,
  detalle_lugar text,
  contextual_type boolean,
  contextual_info text,
  fuente text,
  fechafuente date,
  enlace text,
  personas_texto text,
  medidas_texto text,
  texto_busqueda text
);

insert into public.sig_casos_detalle_2026 (
  caso_id, fecha_evento, anio, macrotipo, subtipos_texto, departamento, macroregion,
  pueblo_texto, npersonas, nmujeres, nhombres, nmenores, macroactor, microactores_texto,
  detalle, detalle_lugar, contextual_type, contextual_info, fuente, fechafuente, enlace,
  personas_texto, medidas_texto, texto_busqueda
)
select
  c.id,
  c.fecha_evento,
  extract(year from c.fecha_evento)::int,
  nullif(btrim(c.macrotipo), ''),
  public._sig_jsonb_text_list(c.subtipos),
  nullif(btrim(c.departamento), ''),
  nullif(btrim(c.macroregion), ''),
  public._sig_jsonb_text_list(c.pueblo),
  coalesce(c.npersonas, 0)::bigint,
  coalesce(c.nmujeres, 0)::bigint,
  coalesce(c.nhombres, 0)::bigint,
  coalesce(c.nmenores, 0)::bigint,
  nullif(btrim(c.macroactor), ''),
  public._sig_jsonb_text_list(c.microactores),
  c.detalle,
  c.detalle_lugar,
  c.contextual_type,
  c.contextual_info,
  c.fuente,
  c.fechafuente,
  c.enlace,
  public._sig_jsonb_text_list(c.personas),
  public._sig_jsonb_text_list(c.medidas),
  lower(concat_ws(' ',
    c.detalle,
    c.detalle_lugar,
    c.contextual_info,
    c.fuente,
    c.enlace,
    c.macrotipo,
    c.macroactor,
    c.departamento,
    c.macroregion,
    public._sig_jsonb_text_list(c.pueblo),
    public._sig_jsonb_text_list(c.subtipos),
    public._sig_jsonb_text_list(c.microactores)
  ))
from public.casos_2026 c;

-- ================================================================
-- 5. Opciones de filtros: una sola fila, consulta inmediata
-- ================================================================

create table public.sig_filtros_opciones_2026 (
  id smallint primary key default 1 check (id = 1),
  anios text[] default '{}',
  departamentos text[] default '{}',
  pueblos text[] default '{}',
  macrotipos text[] default '{}',
  macroregiones text[] default '{}',
  macroactores text[] default '{}',
  actualizado_en timestamp with time zone default now()
);

insert into public.sig_filtros_opciones_2026 (
  id, anios, departamentos, pueblos, macrotipos, macroregiones, macroactores
)
select
  1,
  array(
    select anio::text
    from generate_series(extract(year from now())::int, 2016, -1) as g(anio)
  ),
  array(
    select distinct valor
    from (
      values
        ('Amazonas'), ('Antioquia'), ('Arauca'), ('Atlántico'), ('Bogotá, D.C.'), ('Bolívar'), ('Boyacá'), ('Caldas'),
        ('Caquetá'), ('Casanare'), ('Cauca'), ('Cesar'), ('Chocó'), ('Córdoba'), ('Cundinamarca'), ('Guainía'),
        ('Guaviare'), ('Huila'), ('La Guajira'), ('Magdalena'), ('Meta'), ('Nariño'), ('Norte de Santander'),
        ('Putumayo'), ('Quindío'), ('Risaralda'), ('San Andrés, Providencia y Santa Catalina'), ('Santander'),
        ('Sucre'), ('Tolima'), ('Valle del Cauca'), ('Vaupés'), ('Vichada')
    ) base(valor)
    union
    select distinct departamento from public.sig_casos_lite_2026 where departamento is not null and btrim(departamento) <> ''
    order by 1
  ),
  array(
    select distinct nullif(btrim(pueblo), '')
    from public.sig_casos_lite_2026 c,
         regexp_split_to_table(coalesce(c.pueblo_texto, ''), '\\s*\\|\\s*') as pueblo
    where nullif(btrim(pueblo), '') is not null
    order by 1
  ),
  array(
    select distinct macrotipo from public.sig_casos_lite_2026
    where macrotipo is not null and btrim(macrotipo) <> ''
    order by 1
  ),
  array(
    select distinct valor
    from (
      values ('Amazonía'), ('Andina'), ('Caribe'), ('Orinoquía'), ('Pacífico'), ('Insular')
    ) base(valor)
    union
    select distinct macroregion from public.sig_casos_lite_2026 where macroregion is not null and btrim(macroregion) <> ''
    order by 1
  ),
  array(
    select distinct macroactor from public.sig_casos_lite_2026
    where macroactor is not null and btrim(macroactor) <> ''
    order by 1
  );

-- ================================================================
-- 6. Índices para consultas rápidas desde Supabase/PostgREST
-- ================================================================

create index sig_casos_lite_anio_idx on public.sig_casos_lite_2026 (anio);
create index sig_casos_lite_fecha_idx on public.sig_casos_lite_2026 (fecha_evento desc nulls last);
create index sig_casos_lite_departamento_idx on public.sig_casos_lite_2026 (departamento);
create index sig_casos_lite_macroregion_idx on public.sig_casos_lite_2026 (macroregion);
create index sig_casos_lite_macrotipo_idx on public.sig_casos_lite_2026 (macrotipo);
create index sig_casos_lite_macroactor_idx on public.sig_casos_lite_2026 (macroactor);
create index sig_casos_lite_pueblo_trgm_idx on public.sig_casos_lite_2026 using gin (pueblo_texto gin_trgm_ops);

create index sig_puntos_lite_caso_idx on public.sig_puntos_lite_2026 (caso_id);
create index sig_puntos_lite_municipio_idx on public.sig_puntos_lite_2026 (municipio);
create index sig_puntos_lite_municipio_trgm_idx on public.sig_puntos_lite_2026 using gin (municipio gin_trgm_ops);

create index sig_casos_detalle_anio_idx on public.sig_casos_detalle_2026 (anio);
create index sig_casos_detalle_fecha_idx on public.sig_casos_detalle_2026 (fecha_evento desc nulls last);
create index sig_casos_detalle_departamento_idx on public.sig_casos_detalle_2026 (departamento);
create index sig_casos_detalle_macroregion_idx on public.sig_casos_detalle_2026 (macroregion);
create index sig_casos_detalle_macrotipo_idx on public.sig_casos_detalle_2026 (macrotipo);
create index sig_casos_detalle_macroactor_idx on public.sig_casos_detalle_2026 (macroactor);
create index sig_casos_detalle_pueblo_trgm_idx on public.sig_casos_detalle_2026 using gin (pueblo_texto gin_trgm_ops);
create index sig_casos_detalle_texto_trgm_idx on public.sig_casos_detalle_2026 using gin (texto_busqueda gin_trgm_ops);

-- ================================================================
-- 7. Función de actualización de tablas ligeras
-- ================================================================

create or replace function public.refresh_sig_lite_2026()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  truncate table public.sig_casos_lite_2026;
  truncate table public.sig_puntos_lite_2026 restart identity;
  truncate table public.sig_casos_detalle_2026;
  truncate table public.sig_filtros_opciones_2026;

  insert into public.sig_casos_lite_2026 (
    caso_id, fecha_evento, anio, macrotipo, subtipos_texto, departamento, macroregion,
    pueblo_texto, npersonas, nmujeres, nhombres, nmenores, macroactor, microactores_texto
  )
  select
    c.id,
    c.fecha_evento,
    extract(year from c.fecha_evento)::int,
    nullif(btrim(c.macrotipo), ''),
    public._sig_jsonb_text_list(c.subtipos),
    nullif(btrim(c.departamento), ''),
    nullif(btrim(c.macroregion), ''),
    public._sig_jsonb_text_list(c.pueblo),
    coalesce(c.npersonas, 0)::bigint,
    coalesce(c.nmujeres, 0)::bigint,
    coalesce(c.nhombres, 0)::bigint,
    coalesce(c.nmenores, 0)::bigint,
    nullif(btrim(c.macroactor), ''),
    public._sig_jsonb_text_list(c.microactores)
  from public.casos_2026 c;

  insert into public.sig_puntos_lite_2026 (caso_id, municipio, departamento, macroregion, lat, lng)
  select
    c.id,
    nullif(btrim(cm.municipio), ''),
    nullif(btrim(c.departamento), ''),
    nullif(btrim(c.macroregion), ''),
    cm.lat,
    cm.lng
  from public.casos_2026 c
  join public.caso_municipio_2026 cm on cm.caso_id = c.id
  where cm.lat is not null and cm.lng is not null;

  insert into public.sig_casos_detalle_2026 (
    caso_id, fecha_evento, anio, macrotipo, subtipos_texto, departamento, macroregion,
    pueblo_texto, npersonas, nmujeres, nhombres, nmenores, macroactor, microactores_texto,
    detalle, detalle_lugar, contextual_type, contextual_info, fuente, fechafuente, enlace,
    personas_texto, medidas_texto, texto_busqueda
  )
  select
    c.id,
    c.fecha_evento,
    extract(year from c.fecha_evento)::int,
    nullif(btrim(c.macrotipo), ''),
    public._sig_jsonb_text_list(c.subtipos),
    nullif(btrim(c.departamento), ''),
    nullif(btrim(c.macroregion), ''),
    public._sig_jsonb_text_list(c.pueblo),
    coalesce(c.npersonas, 0)::bigint,
    coalesce(c.nmujeres, 0)::bigint,
    coalesce(c.nhombres, 0)::bigint,
    coalesce(c.nmenores, 0)::bigint,
    nullif(btrim(c.macroactor), ''),
    public._sig_jsonb_text_list(c.microactores),
    c.detalle,
    c.detalle_lugar,
    c.contextual_type,
    c.contextual_info,
    c.fuente,
    c.fechafuente,
    c.enlace,
    public._sig_jsonb_text_list(c.personas),
    public._sig_jsonb_text_list(c.medidas),
    lower(concat_ws(' ', c.detalle, c.detalle_lugar, c.contextual_info, c.fuente, c.enlace,
      c.macrotipo, c.macroactor, c.departamento, c.macroregion,
      public._sig_jsonb_text_list(c.pueblo), public._sig_jsonb_text_list(c.subtipos), public._sig_jsonb_text_list(c.microactores)))
  from public.casos_2026 c;

  insert into public.sig_filtros_opciones_2026 (
    id, anios, departamentos, pueblos, macrotipos, macroregiones, macroactores
  )
  select
    1,
    array(select anio::text from generate_series(extract(year from now())::int, 2016, -1) as g(anio)),
    array(
      select distinct valor
      from (
        values
          ('Amazonas'), ('Antioquia'), ('Arauca'), ('Atlántico'), ('Bogotá, D.C.'), ('Bolívar'), ('Boyacá'), ('Caldas'),
          ('Caquetá'), ('Casanare'), ('Cauca'), ('Cesar'), ('Chocó'), ('Córdoba'), ('Cundinamarca'), ('Guainía'),
          ('Guaviare'), ('Huila'), ('La Guajira'), ('Magdalena'), ('Meta'), ('Nariño'), ('Norte de Santander'),
          ('Putumayo'), ('Quindío'), ('Risaralda'), ('San Andrés, Providencia y Santa Catalina'), ('Santander'),
          ('Sucre'), ('Tolima'), ('Valle del Cauca'), ('Vaupés'), ('Vichada')
      ) base(valor)
      union select distinct departamento from public.sig_casos_lite_2026 where departamento is not null and btrim(departamento) <> ''
      order by 1
    ),
    array(
      select distinct nullif(btrim(pueblo), '')
      from public.sig_casos_lite_2026 c, regexp_split_to_table(coalesce(c.pueblo_texto, ''), '\\s*\\|\\s*') as pueblo
      where nullif(btrim(pueblo), '') is not null
      order by 1
    ),
    array(select distinct macrotipo from public.sig_casos_lite_2026 where macrotipo is not null and btrim(macrotipo) <> '' order by 1),
    array(
      select distinct valor
      from (values ('Amazonía'), ('Andina'), ('Caribe'), ('Orinoquía'), ('Pacífico'), ('Insular')) base(valor)
      union select distinct macroregion from public.sig_casos_lite_2026 where macroregion is not null and btrim(macroregion) <> ''
      order by 1
    ),
    array(select distinct macroactor from public.sig_casos_lite_2026 where macroactor is not null and btrim(macroactor) <> '' order by 1);

  notify pgrst, 'reload schema';
end;
$$;

-- ================================================================
-- 8. Seguridad y permisos
-- ================================================================

alter table public.sig_casos_lite_2026 disable row level security;
alter table public.sig_puntos_lite_2026 disable row level security;
alter table public.sig_filtros_opciones_2026 disable row level security;
alter table public.sig_casos_detalle_2026 disable row level security;

grant usage on schema public to anon;
grant usage on schema public to authenticated;

grant select on table public.sig_casos_lite_2026 to anon;
grant select on table public.sig_puntos_lite_2026 to anon;
grant select on table public.sig_filtros_opciones_2026 to anon;

grant select on table public.sig_casos_lite_2026 to authenticated;
grant select on table public.sig_puntos_lite_2026 to authenticated;
grant select on table public.sig_filtros_opciones_2026 to authenticated;
grant select on table public.sig_casos_detalle_2026 to authenticated;

grant execute on function public.refresh_sig_lite_2026() to authenticated;

notify pgrst, 'reload schema';

commit;

-- Pruebas rápidas sugeridas:
-- select count(*) from public.sig_casos_lite_2026;
-- select count(*) from public.sig_puntos_lite_2026;
-- select * from public.sig_filtros_opciones_2026;
-- select count(*) from public.sig_casos_detalle_2026;
-- select public.refresh_sig_lite_2026();
