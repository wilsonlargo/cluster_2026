-- 11_diagnostico_timeout_sig.sql
-- Diagnóstico rápido cuando una consulta simple del SIG tarda demasiado.

-- 1. Verificar que las tablas ligeras existen y responden desde SQL editor.
select count(*) as casos_lite from public.sig_casos_lite_2026;
select count(*) as puntos_lite from public.sig_puntos_lite_2026;
select * from public.sig_filtros_opciones_2026 limit 1;

-- 2. Ver sesiones que están esperando bloqueos o ejecutando consultas largas.
select
  pid,
  usename,
  state,
  wait_event_type,
  wait_event,
  now() - query_start as duracion,
  left(query, 300) as consulta
from pg_stat_activity
where datname = current_database()
  and pid <> pg_backend_pid()
order by query_start nulls last;

-- 3. Ver bloqueos activos sobre objetos SIG.
select
  l.pid,
  c.relname as objeto,
  l.mode,
  l.granted,
  a.state,
  a.wait_event_type,
  now() - a.query_start as duracion,
  left(a.query, 300) as consulta
from pg_locks l
join pg_stat_activity a on a.pid = l.pid
left join pg_class c on c.oid = l.relation
where c.relname in (
  'sig_filtros_opciones_2026',
  'sig_casos_lite_2026',
  'sig_puntos_lite_2026',
  'sig_casos_detalle_2026'
)
order by l.granted, duracion desc;

-- 4. Si necesitas forzar refresco de caché PostgREST.
notify pgrst, 'reload schema';
