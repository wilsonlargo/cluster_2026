SIG · Departamentos destacados v1

Archivos modificados:
- sigindex.html
- configlayers.js

Qué agrega:
- Nuevo menú Funcionalidades > Departamentos destacados.
- Lista de departamentos tomada de ./Layers/003departamentos.geojson.
- Agregar uno o varios departamentos al mapa.
- Quitar departamentos individualmente.
- Limpiar todos los departamentos seleccionados.
- Ajustar el mapa al departamento seleccionado o a todos los seleccionados.
- La capa seleccionada es independiente y queda en paneDepartamentosSeleccionados, por encima de la capa Departamentos y por debajo de los puntos de casos.

No modifica la capa base de departamentos, filtros, mapa de calor, consola ni rutas de desplazamiento.

Instalación:
1. Reemplazar sigindex.html y configlayers.js en la carpeta SIG.
2. Conservar datasig.js, consolasig.js, desplazamientosig.js y Layers/.
3. Recargar con Ctrl + Shift + R.
