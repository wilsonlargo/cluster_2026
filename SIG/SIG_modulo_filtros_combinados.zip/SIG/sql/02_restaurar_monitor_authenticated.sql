-- 02_restaurar_monitor_authenticated.sql
-- Objetivo: mantener protegido el SIG público sin dañar el Monitor.
-- El SIG público seguirá usando la función RPC get_sig_casos_mapa_2026() con rol anon.
-- El Monitor, después de iniciar sesión, trabaja con el rol authenticated.

-- 1) Permitir que usuarios autenticados usen el esquema público.
grant usage on schema public to authenticated;

-- 2) Restaurar permisos de administración para las tablas que usa el Monitor.
--    Esto permite SELECT, INSERT, UPDATE y DELETE solo a usuarios con sesión iniciada.
grant select, insert, update, delete on table public.casos_2026 to authenticated;
grant select, insert, update, delete on table public.caso_municipio_2026 to authenticated;
grant select, insert, update, delete on table public.desplazamientos_2026 to authenticated;
grant select, insert, update, delete on table public.personas_2026 to authenticated;

-- 3) Restaurar lectura de catálogos necesarios para formularios del Monitor.
grant select on table public.pueblos to authenticated;
grant select on table public.tipos to authenticated;
grant select on table public.departamentos to authenticated;
grant select on table public.municipios to authenticated;
grant select on table public.macroactor to authenticated;
grant select on table public.actores to authenticated;

-- 4) Restaurar lectura de vistas que usa el Monitor para territorialización.
grant select on table public.vw_casos_2026_territorio to authenticated;

-- 5) Restaurar ejecución de funciones RPC usadas por el Monitor.
--    Esto evita errores por firmas de funciones distintas o futuras funciones del módulo interno.
grant execute on all functions in schema public to authenticated;

-- 6) Mantener bloqueado el acceso anónimo directo a tablas base sensibles.
--    El público no debe consultar estas tablas directamente.
revoke all on table public.casos_2026 from anon;
revoke all on table public.caso_municipio_2026 from anon;
revoke all on table public.desplazamientos_2026 from anon;
revoke all on table public.personas_2026 from anon;
revoke all on table public.vw_casos_2026_territorio from anon;

-- 7) Permitir al público solo la función depurada del SIG.
--    Si la función no existe todavía, ejecuta primero 01_crear_vista_funcion_sig.sql.
grant execute on function public.get_sig_casos_mapa_2026() to anon;

-- 8) Políticas RLS para que el Monitor pueda administrar datos después del login.
--    Nota: estas políticas son amplias para usuarios autenticados.
--    Funcionan si solo las personas administradoras tienen cuenta en Auth.

alter table public.casos_2026 enable row level security;
drop policy if exists monitor_select_casos_2026 on public.casos_2026;
drop policy if exists monitor_insert_casos_2026 on public.casos_2026;
drop policy if exists monitor_update_casos_2026 on public.casos_2026;
drop policy if exists monitor_delete_casos_2026 on public.casos_2026;
create policy monitor_select_casos_2026 on public.casos_2026 for select to authenticated using (true);
create policy monitor_insert_casos_2026 on public.casos_2026 for insert to authenticated with check (true);
create policy monitor_update_casos_2026 on public.casos_2026 for update to authenticated using (true) with check (true);
create policy monitor_delete_casos_2026 on public.casos_2026 for delete to authenticated using (true);

alter table public.caso_municipio_2026 enable row level security;
drop policy if exists monitor_select_caso_municipio_2026 on public.caso_municipio_2026;
drop policy if exists monitor_insert_caso_municipio_2026 on public.caso_municipio_2026;
drop policy if exists monitor_update_caso_municipio_2026 on public.caso_municipio_2026;
drop policy if exists monitor_delete_caso_municipio_2026 on public.caso_municipio_2026;
create policy monitor_select_caso_municipio_2026 on public.caso_municipio_2026 for select to authenticated using (true);
create policy monitor_insert_caso_municipio_2026 on public.caso_municipio_2026 for insert to authenticated with check (true);
create policy monitor_update_caso_municipio_2026 on public.caso_municipio_2026 for update to authenticated using (true) with check (true);
create policy monitor_delete_caso_municipio_2026 on public.caso_municipio_2026 for delete to authenticated using (true);

alter table public.desplazamientos_2026 enable row level security;
drop policy if exists monitor_select_desplazamientos_2026 on public.desplazamientos_2026;
drop policy if exists monitor_insert_desplazamientos_2026 on public.desplazamientos_2026;
drop policy if exists monitor_update_desplazamientos_2026 on public.desplazamientos_2026;
drop policy if exists monitor_delete_desplazamientos_2026 on public.desplazamientos_2026;
create policy monitor_select_desplazamientos_2026 on public.desplazamientos_2026 for select to authenticated using (true);
create policy monitor_insert_desplazamientos_2026 on public.desplazamientos_2026 for insert to authenticated with check (true);
create policy monitor_update_desplazamientos_2026 on public.desplazamientos_2026 for update to authenticated using (true) with check (true);
create policy monitor_delete_desplazamientos_2026 on public.desplazamientos_2026 for delete to authenticated using (true);

alter table public.personas_2026 enable row level security;
drop policy if exists monitor_select_personas_2026 on public.personas_2026;
drop policy if exists monitor_insert_personas_2026 on public.personas_2026;
drop policy if exists monitor_update_personas_2026 on public.personas_2026;
drop policy if exists monitor_delete_personas_2026 on public.personas_2026;
create policy monitor_select_personas_2026 on public.personas_2026 for select to authenticated using (true);
create policy monitor_insert_personas_2026 on public.personas_2026 for insert to authenticated with check (true);
create policy monitor_update_personas_2026 on public.personas_2026 for update to authenticated using (true) with check (true);
create policy monitor_delete_personas_2026 on public.personas_2026 for delete to authenticated using (true);
