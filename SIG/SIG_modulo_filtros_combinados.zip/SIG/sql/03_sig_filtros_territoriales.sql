-- 03_sig_filtros_territoriales.sql
-- Funciones públicas controladas para el panel de filtros del módulo SIG.
-- Estas funciones permiten consultar datos depurados para el mapa sin exponer
-- directamente la tabla interna casos_2026 al rol anon.

-- ================================================================
-- 1. Función principal: devuelve casos filtrados y lugares agregados.
--    Incluye casos sin coordenadas para que el panel pueda contar todos
--    los registros vinculados al filtro territorial o temático.
-- ================================================================

drop function if exists public.get_sig_casos_mapa_filtrado_2026(
  integer,
  text,
  text,
  text,
  text,
  text
);

create or replace function public.get_sig_casos_mapa_filtrado_2026(
  p_anio integer default null,
  p_departamento text default null,
  p_pueblo text default null,
  p_macrotipo text default null,
  p_macroregion text default null,
  p_macroactor text default null
)
returns table (
  caso_id uuid,
  fecha_evento date,
  anio int,
  macrotipo text,
  subtipos jsonb,
  departamento text,
  macroregion text,
  pueblo jsonb,
  npersonas bigint,
  nmujeres bigint,
  nhombres bigint,
  nmenores bigint,
  macroactor text,
  microactores jsonb,
  departamentos text[],
  macroregiones text[],
  lugares jsonb
)
language sql
security definer
set search_path = public
as $$
  select
    c.id as caso_id,
    c.fecha_evento,
    extract(year from c.fecha_evento)::int as anio,
    c.macrotipo,
    c.subtipos,
    c.departamento,
    c.macroregion,
    c.pueblo,
    coalesce(c.npersonas, 0) as npersonas,
    coalesce(c.nmujeres, 0) as nmujeres,
    coalesce(c.nhombres, 0) as nhombres,
    coalesce(c.nmenores, 0) as nmenores,
    c.macroactor,
    c.microactores,

    array_remove(array_agg(distinct nullif(btrim(c.departamento), '')), null) as departamentos,
    array_remove(array_agg(distinct nullif(btrim(c.macroregion), '')), null) as macroregiones,

    coalesce(
      jsonb_agg(
        distinct jsonb_build_object(
          'municipio', cm.municipio,
          'departamento', c.departamento,
          'macroregion', c.macroregion,
          'lat', cm.lat,
          'lng', cm.lng
        )
      ) filter (where cm.id is not null),
      '[]'::jsonb
    ) as lugares

  from public.casos_2026 c
  left join public.caso_municipio_2026 cm
    on cm.caso_id = c.id
  where
    (p_anio is null or extract(year from c.fecha_evento)::int = p_anio)
    and (p_departamento is null or norm_txt(c.departamento) = norm_txt(p_departamento))
    and (p_macrotipo is null or norm_txt(c.macrotipo) = norm_txt(p_macrotipo))
    and (p_macroregion is null or norm_txt(c.macroregion) = norm_txt(p_macroregion))
    and (p_macroactor is null or norm_txt(c.macroactor) = norm_txt(p_macroactor))
    and (
      p_pueblo is null
      or exists (
        select 1
        from jsonb_array_elements_text(
          case
            when jsonb_typeof(c.pueblo) = 'array' then c.pueblo
            else '[]'::jsonb
          end
        ) as ptxt(valor)
        where norm_txt(ptxt.valor) = norm_txt(p_pueblo)
      )
    )
  group by
    c.id,
    c.fecha_evento,
    c.macrotipo,
    c.subtipos,
    c.departamento,
    c.macroregion,
    c.pueblo,
    c.npersonas,
    c.nmujeres,
    c.nhombres,
    c.nmenores,
    c.macroactor,
    c.microactores
  order by c.fecha_evento desc nulls last;
$$;

grant execute on function public.get_sig_casos_mapa_filtrado_2026(integer, text, text, text, text, text) to anon;
grant execute on function public.get_sig_casos_mapa_filtrado_2026(integer, text, text, text, text, text) to authenticated;

-- ================================================================
-- 2. Función de opciones: alimenta los select del panel de filtros.
--    Retorna un objeto JSONB con años, departamentos, pueblos,
--    macrotipos, macroregiones y macroactores.
-- ================================================================

drop function if exists public.get_sig_opciones_filtros_2026();

create or replace function public.get_sig_opciones_filtros_2026()
returns table (opciones jsonb)
language sql
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'anios', (
      select coalesce(jsonb_agg(anio order by anio desc), '[]'::jsonb)
      from generate_series(2016, extract(year from now())::int) as anio
    ),
    'departamentos', (
      select coalesce(jsonb_agg(x.departamento order by x.departamento), '[]'::jsonb)
      from (
        select distinct nullif(btrim(departamento), '') as departamento
        from public.departamentos
        where nullif(btrim(departamento), '') is not null
      ) x
    ),
    'pueblos', (
      select coalesce(jsonb_agg(x.pueblo order by x.pueblo), '[]'::jsonb)
      from (
        select distinct nullif(btrim(p.valor), '') as pueblo
        from public.casos_2026 c
        cross join lateral jsonb_array_elements_text(
          case
            when jsonb_typeof(c.pueblo) = 'array' then c.pueblo
            else '[]'::jsonb
          end
        ) as p(valor)
        where nullif(btrim(p.valor), '') is not null
      ) x
    ),
    'macrotipos', (
      select coalesce(jsonb_agg(x.macrotipo order by x.macrotipo), '[]'::jsonb)
      from (
        select distinct nullif(btrim(macrotipo), '') as macrotipo
        from public.casos_2026
        where nullif(btrim(macrotipo), '') is not null
      ) x
    ),
    'macroregiones', (
      select coalesce(jsonb_agg(x.macroregion order by x.macroregion), '[]'::jsonb)
      from (
        select distinct nullif(btrim(macroregion), '') as macroregion
        from public.casos_2026
        where nullif(btrim(macroregion), '') is not null
      ) x
    ),
    'macroactores', (
      select coalesce(jsonb_agg(x.macroactor order by x.macroactor), '[]'::jsonb)
      from (
        select distinct nullif(btrim(macroactor), '') as macroactor
        from public.casos_2026
        where nullif(btrim(macroactor), '') is not null
      ) x
    )
  ) as opciones;
$$;

grant execute on function public.get_sig_opciones_filtros_2026() to anon;
grant execute on function public.get_sig_opciones_filtros_2026() to authenticated;
