-- 01_crear_vista_funcion_sig.sql
-- Objetivo: preparar una salida pública controlada para el módulo SIG.
-- Esta vista y esta función permiten consultar datos resumidos para el mapa
-- sin exponer directamente la tabla interna public.casos_2026 en el frontend.

-- ============================================================
-- 1. Vista depurada para el módulo SIG
-- ============================================================
-- La vista toma la tabla principal casos_2026 y la une con la vista territorial
-- vw_casos_2026_territorio, que ya consolida departamentos, macroregiones
-- y lugares con coordenadas lat/lng.

create or replace view public.vw_sig_casos_mapa_2026 as
select
  c.id as caso_id,
  c.fecha_evento,
  extract(year from c.fecha_evento)::int as anio,
  c.macrotipo,

  -- Se normalizan campos jsonb para que el frontend siempre reciba arreglos.
  case
    when jsonb_typeof(c.subtipos) = 'array' then c.subtipos
    else '[]'::jsonb
  end as subtipos,

  c.departamento,
  c.macroregion,

  case
    when jsonb_typeof(c.pueblo) = 'array' then c.pueblo
    else '[]'::jsonb
  end as pueblo,

  coalesce(c.npersonas, 0) as npersonas,
  coalesce(c.nmujeres, 0) as nmujeres,
  coalesce(c.nhombres, 0) as nhombres,
  coalesce(c.nmenores, 0) as nmenores,

  c.macroactor,

  case
    when jsonb_typeof(c.microactores) = 'array' then c.microactores
    else '[]'::jsonb
  end as microactores,

  coalesce(t.departamentos, array[]::text[]) as departamentos,
  coalesce(t.macroregiones, array[]::text[]) as macroregiones,
  coalesce(t.lugares, '[]'::jsonb) as lugares
from public.casos_2026 c
left join public.vw_casos_2026_territorio t
  on t.caso_id = c.id;

comment on view public.vw_sig_casos_mapa_2026 is
'Vista depurada para el SIG público. No incluye detalle, personas, medidas, contextual_info ni enlace.';

-- ============================================================
-- 2. Función RPC pública controlada para pintar todos los registros
-- ============================================================
-- El frontend llamará esta función con:
-- supabase.rpc('get_sig_casos_mapa_2026')
-- La función devuelve únicamente campos preparados para mapa y filtros.

create or replace function public.get_sig_casos_mapa_2026()
returns table (
  caso_id uuid,
  fecha_evento date,
  anio int,
  macrotipo text,
  subtipos jsonb,
  departamento text,
  macroregion text,
  pueblo jsonb,
  npersonas bigint,
  nmujeres bigint,
  nhombres bigint,
  nmenores bigint,
  macroactor text,
  microactores jsonb,
  departamentos text[],
  macroregiones text[],
  lugares jsonb
)
language sql
stable
security definer
set search_path = public
as $$
  select
    v.caso_id,
    v.fecha_evento,
    v.anio,
    v.macrotipo,
    v.subtipos,
    v.departamento,
    v.macroregion,
    v.pueblo,
    v.npersonas,
    v.nmujeres,
    v.nhombres,
    v.nmenores,
    v.macroactor,
    v.microactores,
    v.departamentos,
    v.macroregiones,
    v.lugares
  from public.vw_sig_casos_mapa_2026 v
  where v.lugares is not null
    and jsonb_typeof(v.lugares) = 'array'
    and jsonb_array_length(v.lugares) > 0;
$$;

comment on function public.get_sig_casos_mapa_2026() is
'RPC pública controlada para entregar registros resumidos del SIG con lugares y coordenadas.';

-- ============================================================
-- 3. Permisos mínimos para acceso público sin contraseña
-- ============================================================
-- Se bloquea el acceso directo anónimo a tablas/vistas internas usadas por el SIG.
-- No se toca el rol authenticated para evitar afectar el módulo Monitor.

revoke all on table public.casos_2026 from anon;
revoke all on table public.caso_municipio_2026 from anon;
revoke all on table public.vw_casos_2026_territorio from anon;
revoke all on table public.vw_sig_casos_mapa_2026 from anon;

-- Se permite al rol anon ejecutar solo la función depurada del SIG.
grant execute on function public.get_sig_casos_mapa_2026() to anon;

-- También se permite a usuarios autenticados usarla, por si luego se reutiliza dentro del Monitor.
grant execute on function public.get_sig_casos_mapa_2026() to authenticated;

-- ============================================================
-- 4. Prueba rápida después de ejecutar el script
-- ============================================================
-- Ejecuta esta consulta en el SQL Editor para validar que responde:
-- select * from public.get_sig_casos_mapa_2026() limit 5;

-- Nota: no se activa RLS en este script para no romper consultas existentes del Monitor.
-- La activación de RLS se recomienda como fase posterior, agregando primero políticas
-- específicas para el rol authenticated que usa el Monitor.
