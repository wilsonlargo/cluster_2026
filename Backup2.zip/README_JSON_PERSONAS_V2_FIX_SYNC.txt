MONITOR JSON PERSONAS V2 FIX SYNC

Corrige el error:
ReferenceError: syncCasoDepartamentoMacroregion is not defined

Cambios:
- La función Pegar JSON ya no llama a syncCasoDepartamentoMacroregion.
- Se agregó sincronización propia y segura de departamento/macroregion desde lugares[].
- Se insertan personas[] en public.personas_2026 con caso_id.
- Se normalizan lat/lng con coma o punto.
- El modal muestra conteo de personas y lugares reconocidos.

Reemplazar:
- monitor.html
- js/main.js

Recargar navegador con Ctrl + Shift + R.
