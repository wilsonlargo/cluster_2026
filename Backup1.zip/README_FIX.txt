Monitor fix fecha/fuente v1

Cambios:
- Botón Guardar ahora incluye fecha_evento, fuente, fechafuente, enlace y contextual_info.
- fecha_evento se autosalva al cambiar o salir del campo.
- fuente, fecha fuente y enlace se autosalvan.
- Se cambió la versión del script en monitor.html para evitar caché.
